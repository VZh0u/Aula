<p style="text-align:center;">Conteúdo do Animated Modal
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tempus venenatis velit ut vulputate.
  Nullam hendrerit, felis vitae blandit porta, mi arcu ultricies neque, nec volutpat tellus felis non mi. Aliquam varius imperdiet eleifend.
  Nam sit amet laoreet justo, non dictum nunc. Nullam ac ipsum mi. Nulla ultrices, nibh at sagittis tincidunt, nulla lorem volutpat massa,
  at maximus arcu nunc sed sapien. Nam dignissim placerat nibh, at mollis nisl scelerisque sed. Vestibulum ante ipsum primis in faucibus
  orci luctus et ultrices posuere cubilia Curae; Ut facilisis augue non augue laoreet ornare. Aenean pharetra eu tellus quis scelerisque.
  Aenean nec cursus leo. Pellentesque eu est vitae augue feugiat accumsan eget sit amet tortor. Integer bibendum dui orci, at egestas nulla
  volutpat eu. Sed iaculis nulla a ex porta, a tempor ex dictum. Donec congue augue non eleifend aliquet. Aenean eu arcu id odio porta
  laoreet non ut mi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis laoreet gravida
  pharetra. Donec dui justo, sollicitudin nec diam sed, ultrices ultrices massa. Fusce et consequat felis, venenatis fermentum massa.
  Aenean eu dapibus enim. Curabitur venenatis nec metus id tristique. Proin lorem neque, mattis suscipit erat id, ultricies volutpat dolor.
  Morbi sit amet enim ipsum. Donec finibus luctus accumsan.</p></p>
