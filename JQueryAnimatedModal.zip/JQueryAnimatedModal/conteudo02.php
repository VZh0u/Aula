<p>
  <div class="col-lg-offset-3 text-left pl-5" style="font-size: 110%;color:black;">
    <a style="">Primeiro, faça o download do arquivo .zip das extensões do Animated Modal <img class="pl-3" src="https://icon-icons.com/icons2/933/PNG/32/forward-right-arrow-button_icon-icons.com_72748.png" alt=""> </a>
    <a class="pl-3" href="https://github.com/joaopereirawd/animatedModal.js/archive/master.zip"><button class="btn btn-success">BAIXAR VERSÃO 1.0</button></a><br><br>

    <a>Em seguida, chame a extensão abaixo e, após colocar o arquivo das extensões na mesma pasta do seu projeto, siga o mesmo padrão do exemplo
      para chamar as outras extensões do arquivo .zip.</a><br><br>
    <script src="https://gist.github.com/joaopereirawd/d64c54b943e9e7469c59.js"></script><br>

    <a><b></b>A div com a classe <b>"close-animatedModal"</b> refere-se a área que fechará o modal animado e na div com a classe <b>"modal-content"</b> ficará o conteúdo do modal.
    </a><br><br>
    <script src="https://gist.github.com/joaopereirawd/1d458515e2a8eec54b3b.js"></script>
    <br><a>AAAAAAAAAAA</a><br><br>
    <link rel="stylesheet" href="https://github.githubassets.com/assets/gist-embed-123720f37c57ce9a8f29de081c38ed61.css">
    <div id="gist19683479" class="gist">

    <script src="https://gist.github.com/joaopereirawd/115ce3f21d505e81568e.js"></script><br>
    <a>AAAAAAAAAAA</a><br><br>
    <div id="gist19683791" class="gist">
      <div class="gist-file">
        <div class="gist-data">
          <div class="js-gist-file-update-container js-task-list-container file-box">
            <div id="file-basicinitialize-html" class="file">
              <div itemprop="text" class="Box-body p-0 blob-wrapper data type-html ">
                <table class="highlight tab-size js-file-line-container" data-tab-size="8">
                  <tbody>
                    <tr>
                      <td id="file-basicinitialize-html-L1" class="blob-num js-line-number" data-line-number="1"></td>
                      <td id="file-basicinitialize-html-LC1" class="blob-code blob-code-inner js-file-line">&lt;<span class="pl-ent">script</span>&gt;<span class="pl-s1"></span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L2" class="blob-num js-line-number" data-line-number="2"></td>
                      <td id="file-basicinitialize-html-LC2" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">$</span>(<span class="pl-s"><span class="pl-pds">"</span>#demo01<span class="pl-pds">"</span></span>).<span class="pl-en">animatedModal</span>({</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="3"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>position: <span class="pl-s"><span class="pl-pds"></span>'fixed'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="4"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>width: <span class="pl-s"><span class="pl-pds"></span>'100%'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="5"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>height: <span class="pl-s"><span class="pl-pds"></span>'100%'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="6"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>top: <span class="pl-s"><span class="pl-pds"></span>'0px'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="7"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>left: <span class="pl-s"><span class="pl-pds"></span>'0px'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="8"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>color: <span class="pl-s"><span class="pl-pds"></span>'#39BEB9'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="9"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>animatedIn: <span class="pl-s"><span class="pl-pds"></span>'zoomIn'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="10"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>animatedOut: <span class="pl-s"><span class="pl-pds"></span>'zoomOut'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="11"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>animationDuration: <span class="pl-s"><span class="pl-pds"></span>'.6s'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="12"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en">    </span>overflow: <span class="pl-s"><span class="pl-pds"></span>'auto'<span class="pl-pds"></span></span>,</span></td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L3" class="blob-num js-line-number" data-line-number="17"></td>
                      <td id="file-basicinitialize-html-LC3" class="blob-code blob-code-inner js-file-line"><span class="pl-s1">  <span class="pl-en"></span>});</td>
                    </tr>
                    <tr>
                      <td id="file-basicinitialize-html-L10" class="blob-num js-line-number" data-line-number="18"></td>
                      <td id="file-basicinitialize-html-LC10" class="blob-code blob-code-inner js-file-line"><span class="pl-s1"></span>&lt;/<span class="pl-ent">script</span>&gt;</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</p>
</div>
